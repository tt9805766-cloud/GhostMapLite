# GhostMap Lite — independent Android prototype

A clean-room Android utility starter project. It does not reuse GhostMap proprietary code/assets and does not bypass paid features.

## Implemented
- Local profiles saved in SharedPreferences as JSON.
- Export profile data through Android's share sheet.
- Macro checklist editor (stores steps; does not inject taps into other apps).
- OpenStreetMap + Leaflet map view with temporary long-press markers.
- Floating quick panel using Android overlay permission.
- App-process memory estimate and shortcut to Android app settings.

## Requirements
- Android Studio Ladybug or newer
- JDK 17
- Android SDK Platform 35
- Internet for map tiles and Leaflet CDN
- Android 8.0+ (API 26+)

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install missing Android SDK components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Debug APK normally appears at `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, with a compatible Gradle installation:
```bash
gradle assembleDebug
```

## Permissions and limitations
- Floating panel: grant **Display over other apps** in Android special app access.
- Map uses OpenStreetMap data and Leaflet from public CDNs; keep attribution and comply with their policies.
- Macro is intentionally a checklist-only prototype. Cross-app automation requires explicit user-consented accessibility design and may be restricted by apps/games.
- Memory figure reports this app process's PSS, not device-wide RAM or FPS.
- No location permission is requested; map starts at a generic regional view and markers are session-only.
- This is source code, not a precompiled APK. Compile and test on a device before daily use.

## Structure
- `app/src/main/java/com/example/ghostmaplite/MainActivity.kt`
- `app/src/main/java/com/example/ghostmaplite/FloatingToolService.kt`
- `app/src/main/AndroidManifest.xml`
