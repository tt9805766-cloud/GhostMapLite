package com.example.ghostmaplite

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Debug
import android.provider.Settings
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ghostmap_lite", MODE_PRIVATE) }
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(15, 20, 28))
        }
        root.addView(TextView(this).apply {
            text = "GHOSTMAP LITE  /  $title"
            textSize = 20f
            setTextColor(Color.rgb(130, 255, 180))
            setPadding(0, 0, 0, 16)
        })
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Home", "Profiles", "Macro", "Map", "Tools").forEach { label ->
            nav.addView(Button(this).apply {
                text = label
                setOnClickListener {
                    when (label) {
                        "Home" -> showHome()
                        "Profiles" -> showProfiles()
                        "Macro" -> showMacro()
                        "Map" -> showMap()
                        else -> showTools()
                    }
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(nav)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 18, 0, 0)
        }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addText(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 8)
        })
    }
    private fun addButton(label: String, action: () -> Unit) {
        content.addView(Button(this).apply { text = label; setOnClickListener { action() } })
    }
    private fun showHome() {
        base("CONTROL CENTER")
        addText("Standalone utility prototype. No premium bypasses or account spoofing.")
        addText("Modules: local profiles, macro checklist, map markers, floating panel, memory estimate.")
        addButton("Open profiles") { showProfiles() }
        addButton("Floating tool panel") { startOverlay() }
        addButton("Performance snapshot") { showTools() }
    }

    private fun showProfiles() {
        base("PROFILES")
        val name = EditText(this).apply { hint = "Profile name"; setSingleLine(true) }
        val config = EditText(this).apply { hint = "Notes / configuration"; minLines = 2 }
        content.addView(name); content.addView(config)
        addButton("Save profile") {
            val n = name.text.toString().trim()
            if (n.isEmpty()) { toast("Enter a profile name"); return@addButton }
            val arr = JSONArray(prefs.getString("profiles", "[]"))
            arr.put(JSONObject().put("name", n).put("config", config.text.toString())
                .put("updatedAt", System.currentTimeMillis()))
            prefs.edit().putString("profiles", arr.toString()).apply()
            toast("Profile saved locally")
            showProfiles()
        }
        addButton("Export profiles to text") {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, prefs.getString("profiles", "[]"))
            startActivity(Intent.createChooser(send, "Export GhostMap Lite profiles"))
        }
        val arr = JSONArray(prefs.getString("profiles", "[]"))
        if (arr.length() == 0) addText("No profiles saved yet.")
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            addText("• ${obj.optString("name")}\n${obj.optString("config")}")
        }
    }

    private fun showMacro() {
        base("MACRO LAB")
        addText("Safe prototype: store a named checklist for your own workflow.")
        addText("This version does not inject touches into other apps or bypass app/game protections.")
        val name = EditText(this).apply { hint = "Macro name"; setSingleLine(true) }
        val steps = EditText(this).apply { hint = "Steps, one per line"; minLines = 3 }
        content.addView(name); content.addView(steps)
        addButton("Save macro checklist") {
            val n = name.text.toString().trim()
            if (n.isEmpty()) { toast("Enter a macro name"); return@addButton }
            val arr = JSONArray(prefs.getString("macros", "[]"))
            arr.put(JSONObject().put("name", n).put("steps", steps.text.toString()))
            prefs.edit().putString("macros", arr.toString()).apply()
            toast("Macro checklist saved")
            showMacro()
        }
        val arr = JSONArray(prefs.getString("macros", "[]"))
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            addText("• ${obj.optString("name")}\n${obj.optString("steps")}")
        }
    }

    private fun showMap() {
        base("MAP & MARKERS")
        addText("OpenStreetMap. Long-press the map to place a temporary marker.")
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.webViewClient = WebViewClient()
        val html = "<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>" +
            "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'>" +
            "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>" +
            "<style>html,body,#map{height:100%;margin:0}</style></head><body><div id='map'></div><script>" +
            "const map=L.map('map').setView([20.9,105.5],5);" +
            "L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);" +
            "map.on('contextmenu',e=>{L.marker(e.latlng).addTo(map).bindPopup(e.latlng.lat.toFixed(5)+', '+e.latlng.lng.toFixed(5)).openPopup();});" +
            "</script></body></html>"
        web.loadDataWithBaseURL("https://www.openstreetmap.org", html, "text/html", "UTF-8", null)
        content.addView(web, LinearLayout.LayoutParams(-1, 620))
    }

    private fun showTools() {
        base("QUICK TOOLS")
        val usedMb = Debug.getPss() / 1024f
        addText("App process memory estimate: %.1f MB".format(usedMb))
        addText("This is not device-wide RAM or FPS.")
        addButton("Open Android app settings") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        addButton("Overlay permission settings") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else toast("Overlay permission already granted")
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("Grant display-over-other-apps permission, then tap Floating tool panel again.")
        } else {
            startService(Intent(this, FloatingToolService::class.java))
            toast("Floating panel started")
        }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
