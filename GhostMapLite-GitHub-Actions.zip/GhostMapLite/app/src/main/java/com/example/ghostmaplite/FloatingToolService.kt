package com.example.ghostmaplite

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingToolService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_NOT_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.rgb(25, 35, 45))
        }
        view.addView(TextView(this).apply {
            text = "GHOSTMAP LITE"; setTextColor(Color.rgb(130,255,180)); textSize = 14f
        })
        view.addView(TextView(this).apply {
            text = "Quick panel • local only"; setTextColor(Color.WHITE)
        })
        view.addView(Button(this).apply { text = "Close panel"; setOnClickListener { stopSelf() } })
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 120 }
        windowManager?.addView(view, params)
        panel = view
        return START_NOT_STICKY
    }
    override fun onDestroy() {
        panel?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
}
